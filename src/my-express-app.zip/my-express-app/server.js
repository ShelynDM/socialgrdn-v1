const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware to parse JSON request bodies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
  host: "db host", // IP address of server running MySQL
  user: "admin", // MySQL username
  password: "password", // MySQL password
  database: "mysocialgrdn" // MySQL database name
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ', err);
    return;
  }
  console.log('Connected to MySQL');
});

app.get('/', (req, res) => {
  res.send('Hello World!');
});

// Example endpoint to get data from RDS
app.get('/data', (req, res) => {
  db.query('SELECT * FROM userprofile', (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.json(results);
    }
  });
});

// POST endpoint to register a new user
app.post('/register', (req, res) => {
  const { email, password, firstname, lastname, username, profession, phoneNumber, userAddress, userCity, userProvince, userPostalCode } = req.body;

  if (!email || !password || !firstname || !lastname || !username) {
    return res.status(400).send('Email, password, first name, last name, and username are required');
  }

  const query = 'INSERT INTO userprofile (email, password, first_name, last_name, username, profession, phone_number, address_line1, city, province, postal_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  const values = [email, password, firstname, lastname, username, profession, phoneNumber, userAddress, userCity, userProvince, userPostalCode];

  db.query(query, values, (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(201).send('User registered successfully');
    }
  });
});

// POST endpoint to add user profile
app.post('/addUserProfile', (req, res) => {
  const { firstname, lastname, username, profession, phoneNumber, userAddress, userCity, userProvince, userPostalCode } = req.body;

  if (!firstname || !lastname || !username || !profession || !phoneNumber || !userAddress || !userCity || !userProvince || !userPostalCode) {
    return res.status(400).send('All fields are required');
  }

  const query = 'INSERT INTO userprofile (first_name, last_name, username, profession, phone_number, address_line1, city, province, postal_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(query, [firstname, lastname, username, profession, phoneNumber, userAddress, userCity, userProvince, userPostalCode], (err, results) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(201).send('User profile added successfully');
    }
  });
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${port}/`);
});
