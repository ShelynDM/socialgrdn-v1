const express= require('express');
const bodyParser=require('body-parser');
const cors=require('cors');

const app=express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors());

var mysql = require('mysql');
 
// create a connection variable with the required details
var con = mysql.createConnection({
  host: "mysocialgrdn.cxec4yk4254a.us-east-2.rds.amazonaws.com", // ip address of server running mysql
  user: "admin", // user name to your mysql database
  password: "!SocialGrdn1!", // corresponding password
  database: "mysocialgrdn" // use the specified database
});
 
// make to connection to the database.
con.connect(function(err) {
  if (err) throw err;
  // if connection is successful
 console.log('connection successful');
});

app.get('/',(req,res)=>{
  res.json('OK');
})

app.post('/',(req,res)=>{
	var {name,rollno} =req.body;
	var records = [[req.body.name,req.body.rollno]];
	if(records[0][0]!=null)
	{
		con.query("INSERT into student (name,rollno) VALUES ?",[records],function(err,res,fields){

			if(err) throw err;

			console.log(res);
		});
	}
	res.json('Form recieved');


})

app.listen(3306,()=>{
  console.log("Port 3306");
})